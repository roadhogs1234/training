package com.example.tasksweek1;

public interface SmartHomeDevice {

	public void turnOn();
	public void turnOff();
	String getStatus();

}
