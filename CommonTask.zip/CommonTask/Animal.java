package com.example.tasksweek1;

public interface Animal {
	void eat();
	void sleep();

}
