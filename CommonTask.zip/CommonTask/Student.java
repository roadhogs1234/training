package com.example.tasksweek1;

public class Student extends Person {
String course;
void study() {
	System.out.println(name+" is studying "+course);
}
}
