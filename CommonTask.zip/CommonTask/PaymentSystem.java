package com.example.tasksweek1;

public class PaymentSystem {
	void pay(double amount)
	{
		System.out.println("Amount paid: "+amount);
	}

}
