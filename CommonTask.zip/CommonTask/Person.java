package com.example.tasksweek1;

public class Person {
	String name;
	int age;
	void displayInfo()
	{
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
	}

}
