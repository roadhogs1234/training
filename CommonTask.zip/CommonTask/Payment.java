package com.example.tasksweek1;

public interface Payment {
 void pay(double amount);
}
