package com.example.tasksweek1;

public interface Shape {
	void area();
	void perimeter();

}
