package com.example.tasksweek1;

public class StudentMain{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student();
		s.age=20;
		s.name="Rohit";
		s.course="Java";
		s.displayInfo();
		s.study();
	}

}
