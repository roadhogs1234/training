package com.example.tasksweek1;

public class ShapesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle t=new Triangle(30,20,10);
		Square s=new Square(20);
		t.area();
		t.perimeter();
		s.area();
		s.perimeter();

	}

}
