package encapsulation;
class Product {
    private String productName;
    private double price;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price > 0) { 
            this.price = price;
        } else {
            System.out.println("Price must be positive!");
        }
    }
}

public class Shop {
    public static void main(String[] args) {
        Product product1 = new Product();
        product1.setProductName("Laptop");
        product1.setPrice(1200.50);

        Product product2 = new Product();
        product2.setProductName("Smartphone");
        product2.setPrice(800.75);

        System.out.println("Product 1: " + product1.getProductName() + ", Price: $" + product1.getPrice());
        System.out.println("Product 2: " + product2.getProductName() + ", Price: $" + product2.getPrice());
    }
}
