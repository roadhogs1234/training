package inheritance;

class Ani {
    public void Sound() {
        System.out.println("Animals make some sound");
    }
}
class Dog extends Ani{
    public void makeSound() {
        System.out.println("Dogs Bark");
    }
}

public class Cat extends Ani{
    public void makeSound() {
        System.out.println("Cats Meow");
    }
	
    public static void main(String args[]) {
	   	Ani a= new Ani();
	    Dog myDog = new Dog();
	    Cat myCat = new Cat();
	        
	    a.Sound();
	    myDog.makeSound(); 
	    myCat.makeSound();
	}
}