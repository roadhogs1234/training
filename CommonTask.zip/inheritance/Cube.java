package inheritance;

class Square{
	public Square(int num) {
		System.out.println(num*num);
	}
}

public class Cube extends Square{

	public Cube(int num) {
		super(num);
		System.out.println(num*num*num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cube c = new Cube(5);
	}

}
