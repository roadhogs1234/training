package Abstraction;

public class SmartLight extends Appliance{
	@Override
	public void turnOn() {
		// TODO Auto-generated method stub
		System.out.println("Smart light is turned on");
		
	}

	@Override
	public void turnOff() {
		// TODO Auto-generated method stub
		System.out.println("Smart light is turned off");
		
	}

}
