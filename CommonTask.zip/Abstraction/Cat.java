package Abstraction;

public class Cat implements Animal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Cat is eating");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("Cat is sleeping");
	}
	public static void main(String[] args) {
		Dog d = new Dog();
		Cat c = new Cat();
		c.eat();
		c.sleep();
		d.eat();
		d.sleep();
	}
}
