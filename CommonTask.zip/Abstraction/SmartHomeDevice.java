package Abstraction;

public interface SmartHomeDevice {

	public void turnOn();
	public void turnOff();
	String getStatus();

}
