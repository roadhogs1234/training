package Abstraction;

public abstract class Appliance implements SmartHomeDevice {
String brand;
String status;
public String getStatus() {
	return status;
}
}