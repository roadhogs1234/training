package Abstraction;

public interface Shape {
	
}
