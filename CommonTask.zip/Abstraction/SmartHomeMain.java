package Abstraction;

public class SmartHomeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SmartLight l=new SmartLight();
		l.turnOn();
		l.turnOff();
		
		SmartThermostat t=new SmartThermostat();
		t.turnOn();
		t.turnOff();

	}

}
