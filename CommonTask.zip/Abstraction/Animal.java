package Abstraction;

public interface Animal {
	void eat();
	void sleep();

}
