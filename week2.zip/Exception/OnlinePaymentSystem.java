import java.util.Scanner;
public class OnlinePaymentSystem {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter card number: ");
        String card = sc.nextLine().trim();
        try{
            if(card.length() < 16) throw new InvalidCardException("Invalid card number (must be 16 digits)");
            System.out.println("Payment processed for card: " + card.substring(0,4) + "****");
        }catch(InvalidCardException e){
            System.out.println("Payment failed: " + e.getMessage());
        }finally{
            sc.close();
        }
    }
}