import java.util.Scanner;
public class ATMWithdrawal {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double balance = 500.0;
        System.out.println("Current balance: " + balance);
        System.out.print("Enter withdrawal amount: ");
        double amt = sc.nextDouble();
        try{
            if(amt > balance) throw new InsufficientFundsException("Insufficient funds. Tried to withdraw " + amt);
            balance -= amt;
            System.out.println("Withdrawal success. Remaining balance: " + balance);
        }catch(InsufficientFundsException e){
            System.out.println("ATM Alert: " + e.getMessage());
        }finally{
            sc.close();
        }
    }
}