import java.io.*;
public class FileUploadSystem {
    public static void main(String[] args){
        FileInputStream fis = null;
        try{
            // Try to open a file named 'upload.txt' in working dir
            fis = new FileInputStream("upload.txt");
            System.out.println("File opened successfully. Size: " + fis.available() + " bytes");
            // simulate reading
            byte[] buf = new byte[64];
            int read = fis.read(buf);
            System.out.println("Read " + read + " bytes.");
        }catch(FileNotFoundException e){
            System.out.println("FileUploadSystem: File not found - " + e.getMessage());
        }catch(IOException e){
            System.out.println("FileUploadSystem: I/O error - " + e.getMessage());
        }catch(SecurityException e){
            System.out.println("FileUploadSystem: Security exception - " + e.getMessage());
        }finally{
            if(fis != null){
                try{ fis.close(); }catch(IOException e){}
                System.out.println("File stream closed (finally).");
            }
        }
    }
}