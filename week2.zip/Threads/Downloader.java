import java.util.concurrent.*;
public class Downloader {
    static class ChunkDownloader implements Callable<Boolean>{
        private int id;
        public ChunkDownloader(int id){ this.id = id; }
        public Boolean call() throws Exception{
            System.out.println("Chunk " + id + " starting");
            Thread.sleep(1000 + (long)(Math.random()*2000));
            System.out.println("Chunk " + id + " finished");
            return true;
        }
    }
    public static void main(String[] args) throws Exception {
        int chunks = 5;
        ExecutorService ex = Executors.newFixedThreadPool(3);
        CompletionService<Boolean> cs = new ExecutorCompletionService<>(ex);
        for(int i=0;i<chunks;i++) cs.submit(new ChunkDownloader(i+1));
        int finished = 0;
        while(finished < chunks){
            Future<Boolean> f = cs.take();
            if(f.get()) finished++;
        }
        ex.shutdown();
        System.out.println("Download complete");
    }
}