import java.util.Random;
public class StockMarketSimulation {
    static class StockThread extends Thread {
        private String name;
        private double price;
        private Random rnd = new Random();
        public double latestPrice(){ return price; }
        public StockThread(String name, double start){ this.name=name; this.price=start; }
        public void run(){
            try{
                for(int i=0;i<10;i++){
                    double change = (rnd.nextDouble() - 0.5) * 2; // -1..+1
                    price = Math.round((price + change) * 100.0)/100.0;
                    System.out.println(name + " -> " + price);
                    Thread.sleep(1000 + rnd.nextInt(2000));
                }
            }catch(InterruptedException e){}
        }
    }
    public static void main(String[] args) throws InterruptedException {
        StockThread s1 = new StockThread("AAPL", 170.0);
        StockThread s2 = new StockThread("GOOG", 130.0);
        s1.start(); s2.start();
        // main thread displays periodically
        for(int i=0;i<10;i++){
            System.out.println("[Market Snapshot] AAPL: " + s1.latestPrice() + " | GOOG: " + s2.latestPrice());
            Thread.sleep(1500);
        }
        s1.join(); s2.join();
        System.out.println("Simulation finished.");
    }
}