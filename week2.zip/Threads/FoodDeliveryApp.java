public class FoodDeliveryApp {
    static class StatusUpdater extends Thread {
        public void run(){
            try{
                String[] statuses = {"Order placed","Preparing","Out for delivery","Arrived"};
                for(String s: statuses){
                    System.out.println("[Status] " + s);
                    Thread.sleep(5000);
                }
            }catch(InterruptedException e){
                System.out.println("StatusUpdater interrupted");
            }
        }
    }
    static class ETAPrinter extends Thread {
        public void run(){
            try{
                int eta = 30;
                for(int i=0;i<4;i++){
                    System.out.println("[ETA] " + eta + " mins");
                    eta -= 8;
                    Thread.sleep(5000);
                }
            }catch(InterruptedException e){
                System.out.println("ETAPrinter interrupted");
            }
        }
    }
    public static void main(String[] args){
        new StatusUpdater().start();
        new ETAPrinter().start();
    }
}