public class ClinicConfigSaverDemo {
    public static void main(String[] args) throws Exception {
        Thread t1 = new Thread(() -> { try{ ClinicConfig.hospitalName = "City Clinic A"; ClinicConfig.saveConfig("cliniccfg.dat"); }catch(Exception e){ e.printStackTrace(); }});
        Thread t2 = new Thread(() -> { try{ ClinicConfig.hospitalName = "City Clinic B"; ClinicConfig.saveConfig("cliniccfg.dat"); }catch(Exception e){ e.printStackTrace(); }});
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("ClinicConfig demo done");
    }
}