public class HospitalStatsDemo {
    public static void main(String[] args) throws Exception {
        Runnable addPatient = () -> {
            for(int i=0;i<3;i++){
                HospitalStats.patientCount++;
                try{ HospitalStats.saveStats("stats.dat"); }catch(Exception e){ e.printStackTrace(); }
            }
        };
        Thread t1 = new Thread(addPatient); Thread t2 = new Thread(addPatient);
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Final patientCount: " + HospitalStats.patientCount);
    }
}