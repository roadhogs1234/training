import java.io.Serializable;
public class ClinicConfig implements Serializable {
    private static final long serialVersionUID = 1L;
    public static String hospitalName = "City Clinic";
    public static String location = "Downtown";
    public static synchronized void saveConfig(String file) throws Exception {
        try(java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(new java.io.FileOutputStream(file))){
            oos.writeObject(ClinicConfig.hospitalName);
            oos.writeObject(ClinicConfig.location);
            System.out.println("ClinicConfig saved");
        }
    }
}