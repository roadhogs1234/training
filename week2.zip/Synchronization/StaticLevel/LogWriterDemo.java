public class LogWriterDemo {
    public static void main(String[] args) throws Exception {
        Runnable r = () -> {
            try{ LogWriter.writeLog("systemlog.dat", Thread.currentThread().getName() + " says hello"); }
            catch(Exception e){ e.printStackTrace(); }
        };
        Thread t1 = new Thread(r, "T1"); Thread t2 = new Thread(r, "T2");
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Logs written (static synchronized)");
    }
}