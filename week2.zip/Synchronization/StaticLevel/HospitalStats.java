import java.io.*;
public class HospitalStats implements Serializable {
    private static final long serialVersionUID = 1L;
    public static int patientCount = 0;
    public static synchronized void saveStats(String file) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
            oos.writeObject(patientCount);
            System.out.println("Saved stats: " + patientCount);
        }
    }
}