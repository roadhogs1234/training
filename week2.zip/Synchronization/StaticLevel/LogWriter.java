import java.io.*;
public class LogWriter {
    public static synchronized void writeLog(String file, String msg) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
            oos.writeObject(msg);
            System.out.println("Logged: " + msg);
        }
    }
}