import java.io.Serializable;
public class Doctor implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, name;
    public Doctor(String id, String name){ this.id=id; this.name=name; }
    public String toString(){ return "Doctor["+id+","+name+"]"; }
}