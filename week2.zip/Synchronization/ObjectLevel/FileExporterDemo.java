public class FileExporterDemo {
    public static void main(String[] args) throws Exception {
        Object lockA = new Object();
        Object lockB = new Object();
        FileExporter expA = new FileExporter(lockA, "A.dat");
        FileExporter expB = new FileExporter(lockB, "B.dat");
        Thread t1 = new Thread(() -> { try{ expA.export("Alpha1"); }catch(Exception e){ e.printStackTrace(); }});
        Thread t2 = new Thread(() -> { try{ expA.export("Alpha2"); }catch(Exception e){ e.printStackTrace(); }});
        Thread t3 = new Thread(() -> { try{ expB.export("Beta1"); }catch(Exception e){ e.printStackTrace(); }});
        t1.start(); t2.start(); t3.start();
        t1.join(); t2.join(); t3.join();
        System.out.println("FileExporter demo finished.");
    }
}