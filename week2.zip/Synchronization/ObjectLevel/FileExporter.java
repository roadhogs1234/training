import java.io.*;
import java.util.*;
public class FileExporter {
    private final Object lock;
    private final String file;
    public FileExporter(Object lock, String file){ this.lock = lock; this.file = file; }
    public void export(Object obj) throws IOException {
        synchronized(lock){
            try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
                oos.writeObject(obj);
                System.out.println("Exported to " + file + ": " + obj);
            }
        }
    }
}