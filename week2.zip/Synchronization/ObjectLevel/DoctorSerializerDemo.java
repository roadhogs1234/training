import java.io.*;
public class DoctorSerializerDemo {
    public static void main(String[] args) throws Exception {
        final Doctor d1 = new Doctor("D1","Dr. A");
        final Doctor d2 = new Doctor("D2","Dr. B");
        Runnable r1 = () -> { synchronized(d1){ try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("doc_"+d1.id+".dat"))){ oos.writeObject(d1); System.out.println("Saved " + d1); }catch(Exception e){ e.printStackTrace(); }}};
        Runnable r2 = () -> { synchronized(d2){ try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("doc_"+d2.id+".dat"))){ oos.writeObject(d2); System.out.println("Saved " + d2); }catch(Exception e){ e.printStackTrace(); }}};
        Thread t1 = new Thread(r1); Thread t2 = new Thread(r2);
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Doctor serialization with object-level locks done.");
    }
}