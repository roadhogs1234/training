import java.io.Serializable;
public class PatientReport implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, data;
    public PatientReport(String id, String data){ this.id=id; this.data=data; }
    public String toString(){ return "Report["+id+"]"; }
}