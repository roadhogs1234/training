import java.io.*;
public class PatientReportExporterDemo {
    public void exportReport(PatientReport r){
        synchronized(r){
            try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("report_"+r.id+".dat"))){
                oos.writeObject(r);
                System.out.println("Exported report " + r);
            }catch(Exception e){ e.printStackTrace(); }
        }
    }
    public static void main(String[] args) throws Exception {
        PatientReportExporterDemo demo = new PatientReportExporterDemo();
        PatientReport r1 = new PatientReport("R1","Data1");
        PatientReport r2 = new PatientReport("R2","Data2");
        Thread t1 = new Thread(() -> demo.exportReport(r1));
        Thread t2 = new Thread(() -> demo.exportReport(r2));
        Thread t3 = new Thread(() -> demo.exportReport(r1));
        t1.start(); t2.start(); t3.start();
        t1.join(); t2.join(); t3.join();
        System.out.println("Patient report export demo complete.");
    }
}