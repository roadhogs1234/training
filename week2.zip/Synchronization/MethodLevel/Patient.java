import java.io.Serializable;
public class Patient implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, name;
    public Patient(String id, String name){ this.id=id; this.name=name; }
    public String toString(){ return "Patient["+id+","+name+"]"; }
}