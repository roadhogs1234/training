public class SavePatientDemo {
    public static void main(String[] args) throws Exception {
        final PatientSerializer serializer = new PatientSerializer("patients.dat");
        Thread t1 = new Thread(() -> { try{ serializer.savePatient(new Patient("P1","Alice")); }catch(Exception e){ e.printStackTrace(); }});
        Thread t2 = new Thread(() -> { try{ serializer.savePatient(new Patient("P2","Bob")); }catch(Exception e){ e.printStackTrace(); }});
        t1.start(); t2.start();
        t1.join(); t2.join();
        System.out.println("Patients saved (method-level sync)");
    }
}