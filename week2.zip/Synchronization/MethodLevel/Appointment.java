import java.io.Serializable;
public class Appointment implements Serializable {
    private static final long serialVersionUID = 1L;
    public String doctor, patient;
    public Appointment(String d, String p){ doctor=d; patient=p; }
    public String toString(){ return "Appointment["+doctor+","+patient+"]"; }
}