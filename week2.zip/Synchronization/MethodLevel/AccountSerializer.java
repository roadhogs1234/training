import java.io.*;
public class AccountSerializer {
    private String file;
    public AccountSerializer(String file){ this.file=file; }
    public synchronized void saveTransaction(Account a) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
            oos.writeObject(a);
            System.out.println("Transaction saved: " + a);
        }
    }
}