public class SaveAppointmentDemo {
    public static void main(String[] args) throws Exception {
        final AppointmentSerializer ser = new AppointmentSerializer("appointments.dat");
        Thread t1 = new Thread(() -> { try{ ser.saveAppointment(new Appointment("Dr.A","John")); }catch(Exception e){ e.printStackTrace(); }});
        Thread t2 = new Thread(() -> { try{ ser.saveAppointment(new Appointment("Dr.B","Emma")); }catch(Exception e){ e.printStackTrace(); }});
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Appointments saved");
    }
}