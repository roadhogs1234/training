import java.io.*;
public class PatientSerializer {
    private String file;
    public PatientSerializer(String file){ this.file = file; }
    public synchronized void savePatient(Patient p) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
            
            oos.writeObject(p);
            System.out.println("Saved: " + p);
        }
    }
}