import java.io.Serializable;
public class Account implements Serializable {
    private static final long serialVersionUID = 1L;
    public String accNo;
    public double balance;
    public Account(String accNo, double balance){ this.accNo=accNo; this.balance=balance; }
    public String toString(){ return "Account["+accNo+","+balance+"]"; }
}