public class SaveTransactionDemo {
    public static void main(String[] args) throws Exception {
        final AccountSerializer ser = new AccountSerializer("transactions.dat");
        Thread t1 = new Thread(() -> { try{ ser.saveTransaction(new Account("A1", 1000)); }catch(Exception e){ e.printStackTrace(); }});
        Thread t2 = new Thread(() -> { try{ ser.saveTransaction(new Account("A2", 2000)); }catch(Exception e){ e.printStackTrace(); }});
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Transactions saved (synchronized method)");
    }
}