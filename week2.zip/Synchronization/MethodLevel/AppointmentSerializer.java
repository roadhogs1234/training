import java.io.*;
public class AppointmentSerializer {
    private String file;
    public AppointmentSerializer(String file){ this.file=file; }
    public synchronized void saveAppointment(Appointment a) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))){
            oos.writeObject(a);
            System.out.println("Saved appointment: " + a);
        }
    }
}